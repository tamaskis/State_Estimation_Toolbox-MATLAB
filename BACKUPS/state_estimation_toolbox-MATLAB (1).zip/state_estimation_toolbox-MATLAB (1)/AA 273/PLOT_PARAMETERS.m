%==========================================================================
%
% PLOT_PARAMETERS  Initializes plot parameters.
%
%   plot_parameters = PLOT_PARAMETERS()
%
% Last Update: 2021-07-27
%
%--------------------------------------------------------------------------
%
% -------
% OUTPUT:
% -------
%   plot_parameters - (struct) structure storing plot parameters
%
%==========================================================================
function plot_parameters = PLOT_PARAMETERS()

    % plot positions [x,y,l,w]
    plot_position = [540,300,700,500];
    two_subplot_position = [270,300,1200,500];
    three_subplot_position = [0,300,2000,500];
    tall_subplot_position = [540,100,700,800];

    % line width
    line_width = 1.5;

    % font sizes for standard plot
    axis_font_size = 18;
    legend_font_size = 14;
    title_font_size = 18;

    % larger font sizes
    axis_font_size_big = 24;
    legend_font_size_big = 18;
    title_font_size_big = 24;

    % color for plots [rgb]
    cardinal_red = [140,21,21]/255;
    light_cardinal_red = (1-cardinal_red)*0.75+cardinal_red;

    % default MATLAB colors [rgb]
    matlab_blue = [0,0.4470,0.7410];
    matlab_red = [0.8500,0.3250,0.0980];
    matlab_yellow = [0.9290,0.6940,0.1250];
    matlab_purple = [0.4940,0.1840,0.5560];
    matlab_green = [0.4660,0.6740,0.1880];
    matlab_cyan = [0.3010,0.7450,0.9330];
    matlab_maroon = [0.6350,0.0780,0.1840];

    % lighter default MATLAB colors [rgb]
    matlab_light_blue = (1-matlab_blue)*0.75+matlab_blue;
    matlab_light_red = (1-matlab_red)*0.75+matlab_red;
    matlab_light_yellow = (1-matlab_yellow)*0.75+matlab_yellow;
    matlab_light_purple = (1-matlab_purple)*0.75+matlab_purple;
    matlab_light_green = (1-matlab_green)*0.75+matlab_green;
    matlab_light_cyan = (1-matlab_cyan)*0.75+matlab_cyan;
    matlab_light_maroon = (1-matlab_maroon)*0.75+matlab_maroon;

    % packages plot parameters into single structure
    plot_parameters.plot_position = plot_position;
    plot_parameters.two_subplot_position = two_subplot_position;
    plot_parameters.three_subplot_position = three_subplot_position;
    plot_parameters.tall_subplot_position = tall_subplot_position;
    plot_parameters.line_width = line_width;
    plot_parameters.axis_font_size = axis_font_size;
    plot_parameters.legend_font_size = legend_font_size;
    plot_parameters.title_font_size = title_font_size;
    plot_parameters.axis_font_size_big = axis_font_size_big;
    plot_parameters.legend_font_size_big = legend_font_size_big;
    plot_parameters.title_font_size_big = title_font_size_big;
    plot_parameters.cardinal_red = cardinal_red;
    plot_parameters.light_cardinal_red = light_cardinal_red;
    plot_parameters.matlab_blue = matlab_blue;
    plot_parameters.matlab_red = matlab_red;
    plot_parameters.matlab_yellow = matlab_yellow;
    plot_parameters.matlab_purple = matlab_purple;
    plot_parameters.matlab_green = matlab_green;
    plot_parameters.matlab_cyan = matlab_cyan;
    plot_parameters.matlab_maroon = matlab_maroon;
    plot_parameters.matlab_light_blue = matlab_light_blue;
    plot_parameters.matlab_light_red = matlab_light_red;
    plot_parameters.matlab_light_yellow = matlab_light_yellow;
    plot_parameters.matlab_light_purple = matlab_light_purple;
    plot_parameters.matlab_light_green = matlab_light_green;
    plot_parameters.matlab_light_cyan = matlab_light_cyan;
    plot_parameters.matlab_light_maroon = matlab_light_maroon;

end