% ps6_problem_1a  Problem Set 6, Problem 1a
%
% Author: Tamas Kis
% Course: AA 273 - State Estimation and Filtering for Robotic Perception
% Last Update: 2021-07-26



%% SCRIPT SETUP

% clears Workspace and Command Window, closes all figures
clear;clc;close all;

% adds path to root directory and all subdirectories
addpath(genpath("../"));

% loads plot parameters
PLOT_PARAMETERS;

% seeds random number generators
rng(2);



%% SIMULATION OF NONLINEAR DISCRETE TIME SYSTEM

% features
m1 = [0;0];
m2 = [10;0];
m3 = [10;10];
m4 = [0;10];

% time parameters
dt = 0.1; % time step [s]
tf = 20; % simulation end time [s]

% time vector and its length
t = 0:dt:tf;
T = length(t);

% dimension parameters
n = 3;
k = 4;

% noise covariances
Q = 0.1*eye(3)*dt;
R = 0.1*eye(4);

% initial state estimate (prior distribution)
mu0 = [0;0;0];
Sigma0 = 0.01*eye(3);

% simulated noise
w = gaussian_random_sample(zeros(n,1),Q,T-1);
v = gaussian_random_sample(zeros(k,1),R,T-1);

% control signal
u = [ones(size(t));sin(t)];

% array preallocation
x = zeros(n,T);
y = zeros(k,T);

% samples initial condition from the prior distribution
x(:,1) = gaussian_random_sample(mu0,Sigma0);

% functions for nonlinear dynamics and nonlinear measurements
f = @(x,u,t) discrete_dynamics(x,u,t,dt);
g = @(x,t) discrete_measurement(x,t,m1,m2,m3,m4);

% simulation
for tt = 1:(T-1)
    
    % propagates state vector with noise
    x(:,tt+1) = f(x(:,tt),u(:,tt),tt)+w(:,tt);
    
    % measurement with noise
    y(:,tt+1) = g(x(:,tt),tt)+v(:,tt);
    
end

% dynamics and measurement Jacobians
A = @(x,u,t) dynamics_jacobian(x,u,t,dt);
C = @(x,t) measurement_jacobian(x,t,m1,m2,m3,m4);

% runs EKF
[mu,Sigma] = EKF(f,g,A,C,Q,R,u,y,mu0,Sigma0);

% +/- 2-sigma bounds
[lower_bound,upper_bound] = sigma_bounds(mu,Sigma,2);

% initializes figure
figure('position',three_subplot_position);

% true x-position and its estimate
subplot(1,3,1);
hold on;
patch([t,fliplr(t)],[upper_bound(1,:),fliplr(lower_bound(1,:))],...
    matlab_light_red,'edgecolor','none','handlevisibility','off');
plot(t,x(1,:),'linewidth',line_width);
plot(t(2:end),mu(1,2:end),'linewidth',line_width);
hold off;
grid on;
axis square;
xlabel('$t\;[\mathrm{s}]$','interpreter','latex','fontsize',...
    axis_font_size);
ylabel('$p_{x}$','interpreter','latex','fontsize',axis_font_size);
legend('true $x$-position',...
    'estimated $x$-position (with $\pm2\sigma$ bound)','interpreter',...
    'latex','fontsize',legend_font_size);

% true y-position and its estimate
subplot(1,3,2);
hold on;
patch([t,fliplr(t)],[upper_bound(2,:),fliplr(lower_bound(2,:))],...
    matlab_light_red,'edgecolor','none','handlevisibility','off');
plot(t,x(2,:),'linewidth',line_width);
plot(t(2:end),mu(2,2:end),'linewidth',line_width);
hold off;
grid on;
axis square;
xlabel('$t\;[\mathrm{s}]$','interpreter','latex','fontsize',...
    axis_font_size);
ylabel('$p_{y}$','interpreter','latex','fontsize',axis_font_size);
legend('true $y$-position',...
    'estimated $y$-position (with $\pm2\sigma$ bound)','interpreter',...
    'latex','fontsize',legend_font_size);

% true heading angle and its estimate
subplot(1,3,3);
hold on;
patch([t,fliplr(t)],[upper_bound(3,:),fliplr(lower_bound(3,:))],...
    matlab_light_red,'edgecolor','none','handlevisibility','off');
plot(t,x(3,:),'linewidth',line_width);
plot(t(2:end),mu(3,2:end),'linewidth',line_width);
hold off;
grid on;
axis square;
xlabel('$t\;[\mathrm{s}]$','interpreter','latex','fontsize',...
    axis_font_size);
ylabel('$\theta\;[\mathrm{rad}]$','interpreter','latex','fontsize',...
    axis_font_size);
legend('true heading angle',...
    'estimated heading angle (with $\pm2\sigma$ bound)','interpreter',...
    'latex','fontsize',legend_font_size);



%% ADDITIONAL FUNCTIONS

%==========================================================================
% discrete_dynamics  Discrete dynamics equation.
%--------------------------------------------------------------------------
%
% ------
% INPUT:
% ------
%   x       - (3×1) state vector at current sample time
%   u       - (2×1) control input at current sample time
%   dt      - (1×1) time step [s]
%
% -------
% OUTPUT:
% -------
%   x_next  - (3×1) state vector at next sample time
%
%==========================================================================
function x_next = discrete_dynamics(x,u,t,dt)

    % unpacks state vector
    px = x(1);
    py = x(2);
    theta = x(3);
    
    % unpacks control vector
    nu = u(1);
    phi = u(2);
    
    % evalutes f(x,u,t)
    x_next = [px+nu*cos(theta)*dt;py+nu*sin(theta)*dt;theta+phi*dt];
    
end



%==========================================================================
% discrete_measurement  Discrete measurement equation.
%--------------------------------------------------------------------------
%
% ------
% INPUT:
% ------
%   x   - (3×1) state vector
%   t 	- (1×1) current iteration (corresponding to discrete time)
%   m1  - (2×1) feature 1 location
%   m2  - (2×1) feature 2 location
%   m3  - (2×1) feature 3 location
%   m4  - (2×1) feature 4 location
%
% -------
% OUTPUT:
% -------
%   y 	- (1×1) measurement
%
%==========================================================================
function g_eval = discrete_measurement(x,t,m1,m2,m3,m4)

    % extracts "p" state vector
    p = x(1:2);
    
    % evalutes g(x,t)
    g_eval = [norm(m1-p);norm(m2-p);norm(m3-p);norm(m4-p)];
                      
end



%==========================================================================
% dynamics_jacobian  Dynamics Jacobian.
%--------------------------------------------------------------------------
%
% ------
% INPUT:
% ------
%   x	- (3×1) state vector
%   u   - (2×1) control input
%   t   - (1×1) current iteration (corresponding to discrete time)
%   dt  - (1×1) time step [s]
%
% -------
% OUTPUT:
% -------
%   A   - (3×3) dynamics Jacobian
%
%==========================================================================
function A = dynamics_jacobian(x,u,t,dt)

    % extracts "theta" from state vector
    theta = x(3);
    
    % extracts "nu" from control input
    nu = u(1);
    
    % assembles dynamics Jacobian
    A = [1   0   -nu*sin(theta)*dt;
         0   1    nu*cos(theta)*dt;
         0   0    1];
    
end



%==========================================================================
% measurement_jacobian  Measurement Jacobian.
%--------------------------------------------------------------------------
%
% ------
% INPUT:
% ------
%   x   - (3×1) state vector
%   t 	- (1×1) current iteration (corresponding to discrete time)
%   m1  - (2×1) feature 1 location
%   m2  - (2×1) feature 2 location
%   m3  - (2×1) feature 3 location
%   m4  - (2×1) feature 4 location
%
% -------
% OUTPUT:
% -------
%   C   - (4×3) measurement Jacobian
%
%==========================================================================
function C = measurement_jacobian(x,t,m1,m2,m3,m4)
    
    % x and y position of robot
    px = x(1);
    py = x(2);
    
    % x and y components of features
    m1x = m1(1);
    m1y = m1(2);
    m2x = m2(1);
    m2y = m2(2);
    m3x = m3(1);
    m3y = m3(2);
    m4x = m4(1);
    m4y = m4(2);
    
    % assembles measurement Jacobian
    C = [(px-m1x)/sqrt((m1x-px)^2+(m1y-py)^2)   (py-m1y)/sqrt((m1x-px)^2+(m1y-py)^2)   0;
         (px-m2x)/sqrt((m2x-px)^2+(m2y-py)^2)   (py-m2y)/sqrt((m2x-px)^2+(m2y-py)^2)   0;
         (px-m3x)/sqrt((m3x-px)^2+(m3y-py)^2)   (py-m3y)/sqrt((m3x-px)^2+(m3y-py)^2)   0;
         (px-m4x)/sqrt((m4x-px)^2+(m4y-py)^2)   (py-m4y)/sqrt((m4x-px)^2+(m4y-py)^2)   0];
    
end